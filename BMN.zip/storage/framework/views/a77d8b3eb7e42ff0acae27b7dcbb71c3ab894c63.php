

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <strong>Data Aset BMN</strong>
        </div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6">Dashboard > Riwayat Aset
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div class="d-grid gap-2 d-md-flex justify-content-md-between">
                    <h4 style="margin: 0">Riwayat Perjalan Aset <?php echo e($riwayat->count() > 0 ? $riwayat[0]->nama_barang : ''); ?></h4>
                    <a href='<?php echo e(url("barang/list")); ?>' class="btn btn-warning me-2 ">kembali</a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive-xl">
                    <table class="table table-hover">
                        <thead>
                            <th class="no">No</th>
                            <th>Kegiatan</th>
                            <th>Penanggung Jawab</th>
                            <th>Mulai</th>
                            <th>Selesai</th>
                            <th>Keterangan</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($data->perihal); ?></td>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e(date('d M Y', strtotime($data->waktu_pakai))); ?> </td>
                                <td><?php echo e($data->waktu_kembali ? date('d M Y', strtotime($data->waktu_kembali)) : '-- -- --'); ?></td>
                                <td><?php echo e($data->ket); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan="6"><h3 class="text-secondary">data not found!</h3></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/barang/riwayat.blade.php ENDPATH**/ ?>