

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12"><strong>Data Invetory</strong></div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6 text-secondary">Dashboard > Data Barang Keluar
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-md px-md-4">
        <?php if(session()->get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <div class="card px-3 py-5">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaksi-list')->html();
} elseif ($_instance->childHasBeenRendered('EFzFFHe')) {
    $componentId = $_instance->getRenderedChildComponentId('EFzFFHe');
    $componentTag = $_instance->getRenderedChildComponentTagName('EFzFFHe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EFzFFHe');
} else {
    $response = \Livewire\Livewire::mount('transaksi-list');
    $html = $response->html();
    $_instance->logRenderedChild('EFzFFHe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js')); ?>/keluar.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/keluar/list.blade.php ENDPATH**/ ?>