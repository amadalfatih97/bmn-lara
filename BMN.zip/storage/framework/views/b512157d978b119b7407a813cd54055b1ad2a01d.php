<div class="modal fade findModal" role="dialog" wire:ignore.self tabindex="-1" role="dialog" 
aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable " role="document">
        <div class="modal-content shadow">
            <div class="modal-header">
                <h6 class="modal-title">Temukan Aset</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div> 
            <div class="modal-body">

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                            
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="Search" aria-label="Search"
                                        autocomplete="off" aria-describedby="button-addon2" wire:model="search" >
                                        <button class="btn btn-outline-secondary" type="button">
                                            <i class="bi bi-search"></i>
                                        </button>
                                    </div>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Nama Barang</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Opsi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index+1); ?></td>
                                            <td>
                                                <?php echo e($item->nama_barang); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->status == 'true' ? 'Sedia' : 'Tidak Tersedia'); ?>

                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-primary btn-sm" <?php echo e($item->status == 'false' ? 'disabled' : ''); ?> wire:click.prevent="onAdding(<?php echo e($item->kode); ?>, '<?php echo e($item->nama_barang); ?>')" 
                                                data-bs-toggle="tooltip" data-bs-placement="left" title="request aset ini" >
                                                    <i class="bi bi-download"></i>
                                                </button> |
                                                <button type="button" class="btn btn-outline-primary btn-sm" wire:click.prevent="detailAset"
                                                data-bs-toggle="tooltip" data-bs-placement="right" title="Lihat Detail" >
                                                    <i class="bi bi-info-lg"></i>
                                                </button> 
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
            
                        </div>
                    </div>
                </div>

                
                <div class="toast-container position-fixed bottom-0 start-50 translate-middle-x p-3">
                    <div class="toast align-items-center text-bg-primary border-2" role="alert" 
                    data-bs-delay="1000" aria-live="assertive" aria-atomic="true">
                        <div class="d-flex">
                            <div class="toast-body">
                                Aset berhasil ditambahkan!
                            </div>
                            <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/livewire/permintaan/modal/find-modal.blade.php ENDPATH**/ ?>