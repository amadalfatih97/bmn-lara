<div class="modal fade addModal" role="dialog" wire:ignore.self tabindex="-1" role="dialog" 
aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered  modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title">Permintaan Barang</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div> 
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card p-3">
                                
                                <form action="<?php echo e(route('permintaan.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    
                                    <div class="mb-3">
                                        <label for="tanggalkeluar" class="form-label">Tanggal Keluar</label>
                                        <input type="text" id="picker" name="tanggalkeluar" wire:model="tglkeluar"
                                            value="<?php echo e(date('Y-m-d')); ?>" class="form-control" required onchange="this.dispatchEvent(new InputEvent('input'))">
                                    </div>
                                    <div class="mb-3">
                                        <div class="row">
                                            <div class="col-md-8 col-sm-12">
                                                <label for="kodebarang" class="form-label">Nama Barang</label>
                                                <select
                                                    class="form-select select-barang <?php echo e($errors->get('kodebarang') ? 'is-invalid'  : ''); ?>"
                                                    aria-label="Default select example" id="select-barang"
                                                    required wire:model="kodebrg" wire:change="findstok($event.target.value)">
                                                    <option value="">---Pilih Barang---</option>
                                                    <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->kode); ?>"><?php echo e($item->namabarang); ?> </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-4 col-sm-12">
                                                <label for="stock" class="form-label">Ready</label>
                                                <input type="text" readonly class="form-control stok-ready"
                                                    id="stok-ready" wire:model="stok">
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="qty" class="form-label">Quantity</label>
                                        <input type="number" wire:model="qty" class="form-control text-capitalize">
                                    </div>
                                    
                                    <button type="button" class="btn btn-primary" wire:click.prevent="addProduct">Tambah</button>
                                    <button type="button" class='btn btn-warning ml-3' data-bs-dismiss="modal" >Cancel</button>
                                    
                                   
                                    <div class="my-3" id=" show-items">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Nama Barang</th>
                                                    <th scope="col">Quantity</th>
                                                    <th scope="col">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($index+1); ?></td>
                                                    <td>
                                                        <input type="hidden"
                                                            class="form-control"
                                                            name="orderProducts[<?php echo e($index); ?>][product_id]"
                                                            wire:model="orderProducts.<?php echo e($index); ?>.product_id"/>
                                                        <input type="text"
                                                            class="form-control"
                                                            name="orderProducts[<?php echo e($index); ?>][namabrg]"
                                                            wire:model="orderProducts.<?php echo e($index); ?>.namabrg"/>
                                                    </td>
                                                    <td>
                                                        <input type="number"
                                                            class="form-control"
                                                            name="orderProducts[<?php echo e($index); ?>][quantity]"
                                                            wire:model="orderProducts.<?php echo e($index); ?>.quantity" />
                                                    </td>
                                                    <td><a href="#" wire:click.prevent="removeProduct(<?php echo e($index); ?>)">Delete</a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            <?php if(count($orderProducts) <= 0): ?>
                                                <tbody id="rowitem">
                                                    <tr>
                                                        <th colspan="4">Item Kosong</th>
                                                    </tr>
                                                    
                                                </tbody>
                                            <?php endif; ?>
                                        </table>
                                    </div>
                                    <button type="submit" 
                                    class='btn btn-success ml-3' id='submit' <?php echo e(count($orderProducts) <= 0 ? 'disabled' : ''); ?>>Submit</button>
                                    
                                </form>
            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/livewire/permintaan/modal/add-modal.blade.php ENDPATH**/ ?>