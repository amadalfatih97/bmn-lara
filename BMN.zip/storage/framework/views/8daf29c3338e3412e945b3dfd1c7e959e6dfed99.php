<?php if($paginator->hasPages()): ?>
    <ul class="pagination pagination-rounded justify-content-center">
        
        
            <li class="<?php echo e($paginator->onFirstPage() ? 'disabled' : ''); ?> page-item"><a href="javascript:;" wire:click="previousPage" class="page-link">Prev</a></li>
        
        
        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($el)): ?>
                <li class="page-item disabled"><a class="page-link"><span><?php echo e($el); ?></span></a></li>
            <?php endif; ?>

            
            <?php if(is_array($el)): ?>
                <?php $__currentLoopData = $el; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page=>$url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="page-item active" aria-current="page"><a href="javascript:;" wire:click="gotoPage(<?php echo e($page); ?>)" class="page-link">
                            <span><?php echo e($page); ?></span>
                        </a>
                    </li>
                    <?php else: ?>
                        <li class="page-item"><a href="javascript:;" wire:click="gotoPage(<?php echo e($page); ?>)" class="page-link"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <li class="<?php echo e($paginator->hasMorePages() ? '' : 'disabled'); ?> page-item">
            <a href="javascript:;" wire:click="nextPage" class="page-link">Next</a>
        </li>
        
    </ul>
<?php endif; ?><?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/livewire/paginate-live.blade.php ENDPATH**/ ?>