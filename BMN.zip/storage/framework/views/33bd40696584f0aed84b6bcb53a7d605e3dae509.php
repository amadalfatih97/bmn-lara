

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12"><strong>Monitoring BMN</strong></div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6 text-secondary">Dashboard > Data Pemeliharaan
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-md px-md-4">
        <div class="card px-3 py-3">
            
            <?php if(session()->get('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session()->get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pemeliharaan-live')->html();
} elseif ($_instance->childHasBeenRendered('I76Ee1q')) {
    $componentId = $_instance->getRenderedChildComponentId('I76Ee1q');
    $componentTag = $_instance->getRenderedChildComponentTagName('I76Ee1q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('I76Ee1q');
} else {
    $response = \Livewire\Livewire::mount('pemeliharaan-live');
    $html = $response->html();
    $_instance->logRenderedChild('I76Ee1q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/pemeliharaan/list.blade.php ENDPATH**/ ?>