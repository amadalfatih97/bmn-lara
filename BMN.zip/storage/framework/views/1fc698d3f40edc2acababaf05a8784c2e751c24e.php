

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <strong>Data Invetory</strong>
        </div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6">Dashboard > edit data barang
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-fluid">
        
        <?php
            $satuanSelect = $barang->satuan_fk;
        ?>
        <?php if($errors->any()): ?>
        <?php
            $satuanSelect = old('satuan');
        ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card p-3">
                    <form action="/barang/update/<?php echo e($barang->id); ?>" method="post">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
                        <label for="namabarang" class="form-label">Input Nama Aset</label>
                        <div class="mb-3 input-group has-validation">
                            <input type="text" 
                            value="<?php echo e(old('namabarang',$barang->nama_barang)); ?>" 
                            class="form-control 
                            <?php echo e($errors->get('namabarang') ? 'is-invalid'  : ''); ?>"
                            id="exampleInputbarang" 
                            name="namabarang"
                            required>
                        </div>
                        <label for="kode" class="form-label">Kode Aset</label>
                        <div class="mb-3 input-group has-validation">
                            <input type="text" 
                            value="<?php echo e(old('kode',$barang->kode)); ?>" class="form-control
                            <?php echo e($errors->get('kode') ? 'is-invalid'  : ''); ?>" id="exampleInputbarang" 
                            id="exampleInputbarang" name="kode" required>
                        </div>
                        <div class="mb-3 text-capitalize">
                            <label for="stok" class="form-label">stok</label>
                            <input type="number" value="<?php echo e(old('stok',$barang->stok)); ?>" class="form-control  
                                <?php echo e($errors->get('stok') ? 'is-invalid'  : ''); ?>"
                                id="exampleInputstok" name="stok" required>
                        </div>
                        <div class="mb-3 text-capitalize">
                            <label for="idsatuan" class="form-label">satuan</label>
                            <select class="form-select  <?php echo e($errors->get('satuan') ? 'is-invalid'  : ''); ?>" name="satuan" aria-label="Default select example" required>
                                <option>Pilih Satuan</option>
                                <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $satuanSelect ? 'selected' : ''); ?>><?php echo e($item->nama_satuan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="lokasi" class="form-label">Ruang / Lokasi Alat</label>
                            <select class="form-select  <?php echo e($errors->get('lokasi') ? 'is-invalid'  : ''); ?>"
                                name="lokasi" aria-label="Default select example" required>
                                <option>Pilih Lokasi</option>
                                <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $barang->lokasi_fk ? 'selected' : ''); ?>>
                                    <?php echo e($item->nama_lokasi); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="kondisi" class="form-label">Kondisi</label>
                            <select class="form-select  <?php echo e($errors->get('kondisi') ? 'is-invalid'  : ''); ?>"
                                name="kondisi" aria-label="Default select example" required>
                                <option>pilih kondisi</option>
                                <option value="b" <?php echo e($barang->kondisi == "b" ? 'selected' : ''); ?>>Baik</option>
                                <option value="rr" <?php echo e($barang->kondisi == "rr" ? 'selected' : ''); ?>>Rusak Ringan</option>
                                <option value="rb"  <?php echo e($barang->kondisi == "rb" ? 'selected' : ''); ?>>Rusak Berat</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select  <?php echo e($errors->get('status') ? 'is-invalid'  : ''); ?>"
                                name="status" aria-label="Default select example" required>
                                <option>pilih status</option>
                                <option value="true" <?php echo e($barang->status == "true" ? 'selected' : ''); ?>>sedia</option>
                                <option value="false" <?php echo e($barang->status == "false" ? 'selected' : ''); ?>>tidak Tersedia</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="ket" class="form-label">Keterangan</label>
                            <textarea class="form-control  
                            <?php echo e($errors->get('ket') ? 'is-invalid'  : ''); ?>" 
                            name="ket" id="exampleFormControlTextarea1" 
                            rows="3"><?php echo e(old('ket',$barang->ket)); ?> </textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a class='btn btn-warning ml-3' href='<?php echo e(url("barang/list")); ?>'>Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/barang/edit.blade.php ENDPATH**/ ?>