

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        
        <h6 class="mb-0">Permintaan Barang</h6>
    </div>
</div>
<div class="pt-3">
    <div class="container-md px-md-4">
        <?php if(session()->get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('permintaan-live')->html();
} elseif ($_instance->childHasBeenRendered('OPE1cua')) {
    $componentId = $_instance->getRenderedChildComponentId('OPE1cua');
    $componentTag = $_instance->getRenderedChildComponentTagName('OPE1cua');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OPE1cua');
} else {
    $response = \Livewire\Livewire::mount('permintaan-live');
    $html = $response->html();
    $_instance->logRenderedChild('OPE1cua', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js')); ?>/permintaan.js"></script>
<script src="<?php echo e(asset('js')); ?>/main.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/Permintaan/list.blade.php ENDPATH**/ ?>