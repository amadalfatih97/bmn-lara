<div style="text-align: center">
    <h2>Form Permintaan Barang</h2>
</div>
<hr>
<table class=" mx-2 my-3 " width="312px">
    <tr>
        <td>Kode </td>
        <td><?php echo e($trans->kode); ?></td>
    </tr>
    <tr>
        <td>Tanggal </td>
        <td><?php echo e(date('d M Y', strtotime($trans->tanggal_trans))); ?></td>
    </tr>
</table>
<hr>

<div class=" mx-2 mb-2">
    <table width="100%">
        <thead>
            <td><b>No</b></td>
            <td><b>Item</b></td>
            <td><b>Quantity</b></td>
            <td><b>Satuan</b></td>
        </thead>
        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <td><?php echo e(++$no); ?></td>
            <td><?php echo e($items->namabarang); ?></td>
            <td><?php echo e($items->quantity); ?></td>
            <td><?php echo e($items->namasatuan); ?></td>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<hr>
<div style="text-align:right; padding:96px 69px 0;">
    <u>
        <b>User Request</b>
    </u>
</div>

<script type="text/javascript">
    window.print();
</script><?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/keluar/report/detail.blade.php ENDPATH**/ ?>