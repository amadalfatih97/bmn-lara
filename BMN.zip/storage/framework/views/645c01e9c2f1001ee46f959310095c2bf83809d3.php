

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12"><strong>Data Invetory</strong></div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6 text-secondary">Dashboard > Data Barang Masuk
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-fluid px-md-4">
        <div class="row">
            <div class="col-md-8 ">
                <a href="<?php echo e(url('barang-masuk/add')); ?>" class="btn btn-success mb-2">input</a>
            </div>
        
            <div class="col-md-4 ">
                <form action='<?php echo e(url("barang-masuk/list")); ?>' method="GET">
                    <div class="input-group mb-3">
                        <input name="key" type="text" class="form-control" placeholder="Search" aria-label="Search"
                            aria-describedby="button-addon2" value="<?php echo e(Request::get('key')); ?>">
                        <button class="btn btn-outline-secondary" type="submit" id="button-addon2">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php if(session()->get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <table class="table table-striped table-hover">
                        <thead>
                            <th class="no">No</th>
                            <th>Nama barang</th>
                            <th>Quantity</th>
                            <th>Satuan</th>
                            <th>Tanggal Masuk</th>
                            
                        </thead>
                        <tbody>
                            <?php $no=1; ?>
                            <?php $__currentLoopData = $masuks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($data->namabarang); ?></td>
                                <td><?php echo e($data->qty); ?></td>
                                <td><?php echo e($data->namasatuan); ?></td>
                                <td><?php echo e($data->tanggalmasuk); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/masuk/list.blade.php ENDPATH**/ ?>