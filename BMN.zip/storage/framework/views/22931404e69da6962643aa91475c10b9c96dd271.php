

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <strong>Data Peminjaman Aset</strong>
        </div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6 text-secondary">Dashboard > Detail Peminjaman
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container">
        <?php if(session()->get('success')): ?>
        <div class="mx-md-3">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session()->get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12 ">
                <div class="card mx-md-3 py-3">
                    <div class="row px-3 ">
                        
                            <div class="col-md-6">
                                <p class="mb-0 text-muted">Waktu Pemakaian:</p>
                                <p> 
                                    <?php echo e(date('d M Y', strtotime($pinjam->waktu_pakai))); ?> 
                                    s/d  <?php echo e($pinjam->waktu_kembali ? date('d M Y', strtotime($pinjam->waktu_kembali)) : '-- -- ----'); ?>

                                </p>
                            </div>
                            <div class="col-md-6">
                                <p class="mb-0 text-muted">Kode: </p>
                                <p> <?php echo e($pinjam->kode); ?></p>
                            </div>
                        
                        <div class="col-md-6">
                            <p class="mb-0 text-muted">Nama Peminjam: </p>
                            <p class="text-capitalize"><?php echo e($pinjam->name); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-0 text-muted">Status: </p>
                            <span role="button" class="badge text-capitalize
                                <?php echo e($pinjam->status == 'pending' ? 'bg-warning' : 
                                ($pinjam->status == 'approved' ? 'bg-info' : 
                                ($pinjam->status == 'applied' ? 'bg-primary' : 'bg-success'))); ?>">
                                <?php echo e($pinjam->status); ?>

                            </span>
                        </div>
                        <div class="col-md-12">
                            <p class="mb-0 text-muted">Keperluan: </p>
                            <div class="card">
                                <div class="card-body text-capitalize p-2">
                                    <?php echo e($pinjam->perihal); ?>

                                </div>
                            </div>
                        </div>
                        
                        <?php if(Auth::user()->role == 'admin' && $pinjam->status == 'pending'): ?>
                            <form action='<?php echo e(url("permintaan/approve/{$pinjam->kode}")); ?>' method="post">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                        <?php elseif(Auth::user()->role == 'admin' && $pinjam->status == 'approved'): ?>
                            <form action='<?php echo e(url("permintaan/applied/{$pinjam->kode}")); ?>' method="post">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                        <?php elseif(Auth::user()->role == 'admin' && $pinjam->status == 'applied'): ?>
                            <form action='<?php echo e(url("permintaan/finished/{$pinjam->kode}")); ?>' method="post">           
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                        <?php endif; ?>
                        
                            <div class="col-md-12 mt-2">
                                <p class="mb-0 text-muted">Keterangan Tambahan</p>
                                <textarea class="form-control bg-light" name="ket" <?php echo e(Auth::user()->role == 'admin' ? '' : 'readonly'); ?>

                                    id="exampleFormControlTextarea1" rows="3"><?php echo e($pinjam->ket); ?></textarea>
                            </div>
                            </div>
                            <hr>
                            <div class=" mx-md-3 mb-md-2">
                                <p class="card-title mx-2"><strong>List Item</strong></p>
                                <table class="table table-striped">
                                    
                                    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($items->qty); ?></td>
                                        <td><?php echo e($items->nama_satuan); ?></td>
                                        <td><?php echo e($items->nama_barang); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <hr>
                            <div class="action d-grid gap-3 d-md-flex justify-content-md-end px-3">
                                
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <button data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    class="btn 
                                        <?php echo e($pinjam->status == 'pending' ? 'btn-info' : 
                                        ($pinjam->status == 'approved' ? 'btn-primary' :'btn-success')); ?>"
                                    title="Setujui permintaan" <?php echo e($pinjam->status == 'finished' ? 'disabled' : ''); ?>>
                                        <i class="bi bi-check2-square"></i>
                                        <?php echo e($pinjam->status == 'pending' ? 'Approve' : 
                                        ($pinjam->status == 'approved' ? 'Apply' : 'Finish')); ?>

                                    </button>
                                <?php endif; ?>
                                
                                
                                <a href='<?php echo e(url("permintaan/list")); ?>' class='btn btn-outline-danger' href='<?php echo e(url("permintaan/list")); ?>' data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="tutup halaman detail"><i class="bi bi-x-circle"></i> Close</a>
                            </div>

                        </form>
                            
                    <hr>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/permintaan/detail.blade.php ENDPATH**/ ?>