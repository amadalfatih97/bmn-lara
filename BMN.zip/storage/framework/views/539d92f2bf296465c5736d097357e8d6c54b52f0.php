<div>
    
    <div class="row">
        <div class="col-md-8 ">
            <a href="<?php echo e(url('barang/add')); ?>" class="btn btn-success mb-2">input</a>
        </div>
    
        <div class="col-md-4 ">
            <form >
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Search" aria-label="Search"
                        aria-describedby="button-addon2" wire:model.debounce.350ms="keyword">
                    <button class="btn btn-outline-secondary" id="button-addon2">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <table class="table table-striped table-hover">
                    <thead>
                        <th class="no">No</th>
                        <th>Nama</th>
                        <th>Satuan</th>
                        <th>Stok</th>
                        <th>Ket</th>
                        <th class="action" colspan=2>Aksi</th>
                    </thead>
                    <tbody>
                        <?php $no=1; ?>
                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($barangs->firstItem() + $key); ?></td>
                            <td><?php echo e($data->namabarang); ?></td>
                            <td><?php echo e($data->namasatuan); ?></td>
                            <td><?php echo e($data->stok); ?></td>
                            <td><?php echo e($data->ket); ?></td>
                            <td>
                                <a class="btn btn-outline-primary"  data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="edit data" href="/barang/<?php echo e($data->id); ?>"><i class="bi bi-pencil-square"></i><span class="hide-to-mobile">Edit</span></a>
                            </td>
                            <td>
                                
                                    
                                    
                                    <button class="btn btn-outline-danger" wire:click="confirmDelete(<?php echo e($data->id); ?>,'Delete','kamu yakin akan menghapus barang ini?')"><i class="bi bi-trash"></i><span class="hide-to-mobile">Hapus</span></button>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                    </tbody>
                </table>
                <?php if(count($barangs)): ?>
                    <?php echo e($barangs->links('livewire/paginate-live')); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/livewire/barang-live.blade.php ENDPATH**/ ?>