<div>
    <div class="row">
        <div class="col-md-8 ">
            <a href="<?php echo e(url('pemeliharaan/add')); ?>" class="btn btn-success mb-2">input</a>
        </div>
    
        <div class="col-md-4 ">
            <form action='<?php echo e(url("pemeliharaan/list")); ?>' method="GET">
                <div class="input-group mb-3">
                    <input name="key" type="text" class="form-control" placeholder="Search" aria-label="Search"
                        aria-describedby="button-addon2"  wire:model.debounce.350ms="keyword">
                    <button class="btn btn-outline-secondary" type="submit" id="button-addon2">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <table class="table table-striped table-hover">
                    <thead>
                        <th class="no">No</th>
                        <th>Tanggal</th>
                        <th>Aset</th>
                        <th>Hasil</th>
                        <th>Tindak Lanjut</th>
                        <th class="action" colspan=2>Aksi</th>
                    </thead>
                    <tbody>
                        <?php $no=1; ?>
                        <?php $__currentLoopData = $pemeliharaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e(date('d M Y', strtotime($data->waktu_pelaksanaan))); ?></td>
                            <td><?php echo e($data->nama_barang); ?></td>
                            <td><?php echo e($data->hasil); ?></td>
                            <td><?php echo e($data->tindak_lanjut); ?></td>
                            <td>
                                <form action='<?php echo e(url("pemeliharaan/delete/{$data->id}")); ?>' method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a class="btn btn-outline-primary" href="/pemeliharaan/<?php echo e($data->id); ?>"><i class="bi bi-info"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lihat detail"></i></a>
                                |
                                    <button class="btn btn-outline-danger" type="submit"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/livewire/pemeliharaan/pemeliharaan-live.blade.php ENDPATH**/ ?>