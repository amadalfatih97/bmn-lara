<div class="offcanvas offcanvas-start bg-dark
    text-white sidebar-nav" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">

    <div class="offcanvas-body p-0">
        <nav class="navbar-dark">
            <ul class="navbar-nav py-3">
                <li>
                    <a class="navbar-brand fw-bold me-auto px-3" href="#">
                        <img src="<?php echo e(asset('images/logo-bdipadang-white.png')); ?>" alt="">
                    </a>
                </li>
                <li>
                    <hr class="dropdown-divider" />
                    <div class="text-muted small fw-bold-text-uppercase px-3">
                        Menu
                    </div>
                </li>
                
                
                <li>
                    <a href='<?php echo e(url("")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == '' ? 'active' : null); ?>">
                        <span class="me-2"><i class="bi bi-house"></i></span>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <?php if(auth()->user()->role=='admin'): ?>
                    <li>
                        <a href='<?php echo e(url("barang/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == 'barang' ? 'active' : null); ?>">
                            <span class="me-2"><i class="bi bi-archive"></i></span>
                            <span>Master Aset BMN</span>
                        </a>
                    </li>
                    
                    <li>
                        <a href='<?php echo e(url("permintaan/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == 'permintaan' ? 'active' : null); ?>">
                            <span class="me-2"><i class="bi bi-clipboard2-check"></i></span>
                            <span>Semua Permintaan</span>
                        </a>
                    </li>

                    <li>
                        <a href='<?php echo e(url("pengguna/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == 'pengguna' ? 'active' : null); ?>">
                            <span class="me-2"><i class="bi bi-person-workspace"></i></span>
                            <span>Pengguna Tetap</span>
                        </a>
                    </li>

                    <li>
                        <a href='<?php echo e(url("pemeliharaan/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == 'pemeliharaan' ? 'active' : null); ?>">
                            <span class="me-2"><i class="bi bi-tools"></i></span>
                            <span>Data Pemeliharaan </span>
                        </a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href='<?php echo e(url("permintaan/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == 'permintaan' ? 'active' : null); ?>">
                            <span class="me-2"><i class="bi bi-files"></i></span>
                            <span>Permintaan Saya</span>
                        </a>
                    </li>
                    <li>
                        <a href='<?php echo e(url("lapor/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == 'permintaan' ? 'active' : null); ?>">
                            <span class="me-2"><i class="bi bi-tools"></i></span>
                            <span>Laporkan Aset</span>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="mt-4">
                    <hr class="dropdown-divider" />
                </li>
                
                <?php if(auth()->user()->role=='admin'): ?>
                    <li>
                        <div class="text-muted small fw-bold-text-uppercase px-3">
                            Other
                        </div>
                    </li>
                    
                    <li>
                        <a href='<?php echo e(url("user/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(1) == 'user' ? 'active' : null); ?>">
                            <span class="me-2"><i class="bi bi-person-workspace"></i></span>
                            <span>Kelola User</span>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link px-3 sidebar-link" data-bs-toggle="collapse" href="#collapseExample"
                            role="button" aria-expanded="false" aria-controls="collapseExample">
                            <span class="me-2"><i class="bi bi-gear"></i></span>
                            <span>Setting</span>
                            <span class="right-icon ms-auto">
                                <i class="bi bi-chevron-down"></i>
                            </span>
                        </a>
                        <div class="collapse <?php echo e(Request::segment(1) == 'setting' ? 'show' : null); ?>" id="collapseExample">
                            <div>
                                <ul class="navbar-nav ps-3">
                                    <li>
                                        <a href='<?php echo e(url("setting/satuan/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(2) == 'satuan' ? 'active' : null); ?>">
                                            <span class="me-2"><i class="bi bi-files"></i></span>
                                            <span>Data Satuan</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href='<?php echo e(url("setting/kategori/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(2) == 'kategori' ? 'active' : null); ?>">
                                            <span class="me-2"><i class="bi bi-files"></i></span>
                                            <span>Data Kategori</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href='<?php echo e(url("setting/lokasi/list")); ?>' class="nav-link px-3 <?php echo e(Request::segment(2) == 'lokasi' ? 'active' : null); ?>">
                                            <span class="me-2"><i class="bi bi-files"></i></span>
                                            <span>Data Lokasi</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a class="nav-link px-3 sidebar-link" data-bs-toggle="collapse" href="#collapseExample2"
                            role="button" aria-expanded="false" aria-controls="collapseExample">
                            <span class="me-2"><i class="bi bi-file-earmark"></i></span>
                            <span>Report</span>
                            <span class="right-icon ms-auto">
                                <i class="bi bi-chevron-down"></i>
                            </span>
                        </a>
                        <div class="collapse" id="collapseExample2">
                            <ul class="navbar-nav ps-3"> 
                                <li>
                                    <a href="" class="nav-link px-3">
                                        <span class="me-2"><i class="bi bi-files"></i></span>
                                        <span>Report 1</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="" class="nav-link px-3">
                                        <span class="me-2"><i class="bi bi-files"></i></span>
                                        <span>Report 1</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    
                <?php endif; ?>
                
                <li>
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link px-3"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        <span class="me-2"><i class="bi bi-box-arrow-left"></i></span>
                        <span> <?php echo e(__('Logout')); ?></span>
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/sidebar.blade.php ENDPATH**/ ?>