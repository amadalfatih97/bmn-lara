<main >
    
    <?php echo $__env->yieldContent('main'); ?>
</main><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/main.blade.php ENDPATH**/ ?>