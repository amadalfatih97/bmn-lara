

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <strong>Data Invetory</strong>
        </div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6">Dashboard > Data User
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-fluid">

    <?php
        $getRole ='';
        $getUnit ='';
        ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card p-3">

                    <form action="<?php echo e(url('/user/add')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="nama" class="form-label">Input Nama User</label>
                            <input type="text" value="<?php echo e(old('nama')); ?>" class="form-control"
                                name="nama" autocomplete="off" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" value="<?php echo e(old('username')); ?>" class="form-control"
                                name="username" autocomplete="off" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" value="<?php echo e(old('password')); ?>" class="form-control"
                                name="password" autocomplete="off" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="unit" class="form-label">Unit</label>
                            <select class="form-select  <?php echo e($errors->get('unit') ? 'is-invalid'  : ''); ?>"
                                name="unit" aria-label="Default select example" required>
                                <option>Pilih Unit</option>
                                <option value="tu" <?php echo e($getUnit == 'tu' ? 'selected' : ''); ?>>Tata Usaha</option>
                                <option value="pd" <?php echo e($getUnit == 'pd' ? 'selected' : ''); ?>>Pelaksana Diklat</option>
                                <option value="pkd" <?php echo e($getUnit == 'pkd' ? 'selected' : ''); ?>>Pengembangan Diklat</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-select  <?php echo e($errors->get('role') ? 'is-invalid'  : ''); ?>"
                                name="role" aria-label="Default select example" required>
                                <option value="">Pilih role</option>
                                <option value="admin" <?php echo e($getRole == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                <option value="pegawai" <?php echo e($getRole == 'pegawai' ? 'selected' : ''); ?>>Pegawai</option>
                                <!-- <option value="rb" <?php echo e($getRole == 'pkd' ? 'selected' : ''); ?>>Pengembangan Diklat</option> -->
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a class='btn btn-warning ml-3' href='<?php echo e(url("user/list")); ?>'>Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/user/input.blade.php ENDPATH**/ ?>