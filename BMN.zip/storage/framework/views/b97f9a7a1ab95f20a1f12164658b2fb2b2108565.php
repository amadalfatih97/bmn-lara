<div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama Barang</th>
                <th scope="col">Quantity</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        
            <tbody id="rowitem">
                <tr>
                    <th colspan="4">Item Kosong</th>
                </tr>
                
            </tbody>
        
    </table>
</div>
<?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/livewire/data-permintaan.blade.php ENDPATH**/ ?>