

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <strong>Data Invetory</strong>
        </div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6">Dashboard > data barang
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-fluid">

        <?php
            $getSelect = '';
            $getLokasi = '';
            $getStatus = '';
            $getKondisi = '';
        ?>
        <?php if($errors->any()): ?>
        <?php
            $getSelect = old('satuan');
            $getLokasi = old('lokasi');
            $getStatus = old('status');
            $getKondisi = old('kondisi');
        ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card p-3">
                    <div class="input-cek mb-3 d-flex">
                        <div class="form-check me-3 radio_wrap" data-radio="radio_1">
                            <input class="form-check-input" type="radio" name="typeinput" id="type-input2" value="1"
                            checked>
                            <label class="form-check-label" for="type-input2">
                                Barang Baru
                            </label>
                        </div>
                        <div class="form-check radio_wrap" data-radio="radio_2">
                            <input class="form-check-input" type="radio" name="typeinput" id="type-input1" value="0"
                                 >
                            <label class="form-check-label" for="type-input1">
                                Barang Sudah Ada
                            </label>
                        </div>
                    </div>
                    <div class="content">
                        <div class="radio_content radio_1" id="barang-baru">
                            <form action="<?php echo e(url('/barang/add')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <label for="namabarang" class="form-label">Input Nama Aset</label>
                                <div class="mb-3 input-group has-validation">
                                    <input type="text" value="<?php echo e(old('namabarang')); ?>" class="form-control 
                                    <?php echo e($errors->get('namabarang') ? 'is-invalid'  : ''); ?>" id="exampleInputbarang"
                                        name="namabarang" required>
                                </div>
                                <label for="kode" class="form-label">Kode Aset</label>
                                <div class="mb-3 input-group has-validation">
                                    <input type="text" value="<?php echo e(old('kode')); ?>" autocomplete="false" class="form-control 
                                    <?php echo e($errors->get('kode') ? 'is-invalid'  : ''); ?>" id="exampleInputbarang" 
                                    id="exampleInputbarang" name="kode" required autocomplete="off">
                                </div>
                                <div class="mb-3">
                                    <label for="satuan" class="form-label">Satuan</label>
                                    <select class="form-select  <?php echo e($errors->get('satuan') ? 'is-invalid'  : ''); ?>"
                                        name="satuan" aria-label="Default select example" required>
                                        <option>Pilih Satuan</option>
                                        <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $getSelect ? 'selected' : ''); ?>>
                                            <?php echo e($item->nama_satuan); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="lokasi" class="form-label">Ruang / Lokasi Alat</label>
                                    <select class="form-select  <?php echo e($errors->get('lokasi') ? 'is-invalid'  : ''); ?>"
                                        name="lokasi" aria-label="Default select example" required>
                                        <option>Pilih Lokasi</option>
                                        <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $getLokasi ? 'selected' : ''); ?>>
                                            <?php echo e($item->nama_lokasi); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="kondisi" class="form-label">Kondisi</label>
                                    <select class="form-select  <?php echo e($errors->get('kondisi') ? 'is-invalid'  : ''); ?>"
                                        name="kondisi" aria-label="Default select example" required>
                                        <option>Pilih Kondisi</option>
                                        <option value="b" <?php echo e($getKondisi == 'b' ? 'selected' : ''); ?>>Baik</option>
                                        <option value="rr" <?php echo e($getKondisi == 'rr' ? 'selected' : ''); ?>>Rusak Ringan</option>
                                        <option value="rb" <?php echo e($getKondisi == 'rb' ? 'selected' : ''); ?>>Rusak Berat</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select  <?php echo e($errors->get('status') ? 'is-invalid'  : ''); ?>"
                                        name="status" aria-label="Default select example" required>
                                        <option>Pilih Status</option>
                                        <option value="true" <?php echo e($getStatus == 'true' ? 'selected' : ''); ?>>sedia</option>
                                        <option value="false" <?php echo e($getStatus == 'false' ? 'selected' : ''); ?>>tidak Tersedia</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="ket" class="form-label">Keterangan</label>
                                    <textarea class="form-control  
                                        <?php echo e($errors->get('ket') ? 'is-invalid'  : ''); ?>" name="ket"
                                        id="exampleFormControlTextarea1" rows="3"><?php echo e(old('ket')); ?> </textarea>
                                </div>

                                <button type="submit" class="btn btn-primary">Submit</button>
                                <a class='btn btn-warning ml-3' href='<?php echo e(url("barang/list")); ?>'>Cancel</a>
                            </form>
                        </div>
                        <!--  -->
                        <div class="radio_content radio_2" id="barang-lama">
                            <form action="<?php echo e(url('/barang/masuk')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <label for="namabarang" class="form-label">Pilih Aset</label>
                                <div class="mb-3 input-group has-validation">
                                    <select class="form-select  <?php echo e($errors->get('namabarang') ? 'is-invalid'  : ''); ?>" id="exampleInputbarang"
                                        name="namabarang" required>
                                        <option>Pilih Satuan</option>
                                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->nama_barang); ?>" <?php echo e($item->nama_barang == $getSelect ? 'selected' : ''); ?>>
                                            <?php echo e($item->nama_barang); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <label for="kode" class="form-label">Kode Aset</label>
                                <div class="mb-3 input-group has-validation">
                                    <input type="text" value="<?php echo e(old('kode')); ?>" autocomplete="false" class="form-control 
                                    <?php echo e($errors->get('kode') ? 'is-invalid'  : ''); ?>" id="exampleInputbarang" 
                                    id="exampleInputbarang" name="kode" required autocomplete="off">
                                </div>
                                <div class="mb-3">
                                    <label for="lokasi" class="form-label">Ruang / Lokasi Alat</label>
                                    <select class="form-select  <?php echo e($errors->get('lokasi') ? 'is-invalid'  : ''); ?>"
                                        name="lokasi" aria-label="Default select example" required>
                                        <option>Pilih Lokasi</option>
                                        <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $getLokasi ? 'selected' : ''); ?>>
                                            <?php echo e($item->nama_lokasi); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="kondisi" class="form-label">Kondisi</label>
                                    <select class="form-select  <?php echo e($errors->get('kondisi') ? 'is-invalid'  : ''); ?>"
                                        name="kondisi" aria-label="Default select example" required>
                                        <option>Pilih Kondisi</option>
                                        <option value="b" <?php echo e($getKondisi == 'b' ? 'selected' : ''); ?>>Baik</option>
                                        <option value="rr" <?php echo e($getKondisi == 'rr' ? 'selected' : ''); ?>>Rusak Ringan</option>
                                        <option value="rb" <?php echo e($getKondisi == 'rb' ? 'selected' : ''); ?>>Rusak Berat</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select  <?php echo e($errors->get('status') ? 'is-invalid'  : ''); ?>"
                                        name="status" aria-label="Default select example" required>
                                        <option>Pilih Status</option>
                                        <option value="true" <?php echo e($getStatus == 'true' ? 'selected' : ''); ?>>sedia</option>
                                        <option value="false" <?php echo e($getStatus == 'false' ? 'selected' : ''); ?>>tidak Tersedia</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="ket" class="form-label">Keterangan</label>
                                    <textarea class="form-control  
                                        <?php echo e($errors->get('ket') ? 'is-invalid'  : ''); ?>" name="ket"
                                        id="exampleFormControlTextarea1" rows="3"><?php echo e(old('ket')); ?> </textarea>
                                </div>

                                <button type="submit" class="btn btn-primary">Submit</button>
                                <a class='btn btn-warning ml-3' href='<?php echo e(url("barang/list")); ?>'>Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js')); ?>/main.js" ></script>
    <script src="<?php echo e(asset('js')); ?>/barang.js" ></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/barang/input.blade.php ENDPATH**/ ?>