

<?php $__env->startSection('main'); ?>


<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        
        <h6 class="mb-0">Data Peminjaman</h6>
    </div>
</div>
<div class="pt-3">
    <div class="container-md px-md-4">
        <?php if(session()->get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('success')); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">

                <div class="row">
                    <div class="col-md-12">
                        <div class="card p-3">
                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('data-permintaan')->html();
} elseif ($_instance->childHasBeenRendered('9Zv9b3I')) {
    $componentId = $_instance->getRenderedChildComponentId('9Zv9b3I');
    $componentTag = $_instance->getRenderedChildComponentTagName('9Zv9b3I');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9Zv9b3I');
} else {
    $response = \Livewire\Livewire::mount('data-permintaan');
    $html = $response->html();
    $_instance->logRenderedChild('9Zv9b3I', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>                                
                        </div>
                    </div>
                </div>
                                    
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js')); ?>/permintaan.js"></script>
<script src="<?php echo e(asset('js')); ?>/main.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/Permintaan/input.blade.php ENDPATH**/ ?>