

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <strong>Data Invetory</strong>
        </div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6">Dashboard > data barang
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-fluid">

        <?php
            $getSelect = '';
        ?>
        <?php if($errors->any()): ?>
        <?php
            $getSelect = old('idsatuan');
        ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card p-3">
                    
                    <form action="<?php echo e(url('/barang/add')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="kode" class="form-label">Kode barang</label>
                        <div class="mb-3 input-group has-validation">
                            <input type="text" value="<?php echo e('INV0'.$last); ?>" class="form-control" 
                            id="exampleInputbarang" name="kode" readonly required>
                        </div>
                        <label for="namabarang" class="form-label">Input Nama barang</label>
                        <div class="mb-3 input-group has-validation">
                            <input type="text" value="<?php echo e(old('namabarang')); ?>" class="form-control 
                            <?php echo e($errors->get('namabarang') ? 'is-invalid'  : ''); ?>" id="exampleInputbarang"
                                name="namabarang" required>
                        </div>
                        <div class="mb-3">
                            <label for="idsatuan" class="form-label">Satuan</label>
                            <select class="form-select  <?php echo e($errors->get('idsatuan') ? 'is-invalid'  : ''); ?>"
                                name="idsatuan" aria-label="Default select example" required>
                                <option>Pilih Satuan</option>
                                <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $getSelect ? 'selected' : ''); ?>>
                                    <?php echo e($item->namasatuan); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="number" value="<?php echo e(old('stok')); ?>" class="form-control  
                            <?php echo e($errors->get('stok') ? 'is-invalid'  : ''); ?>" id="exampleInputstok" name="stok" required>
                        </div>
                        <div class="mb-3">
                            <label for="tanggalmasuk" class="form-label">Tanggal Masuk</label>
                            <input type="text" id="picker" name="tanggalmasuk" 
                             class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="lokasi" class="form-label">Lokasi</label>
                            <textarea class="form-control  <?php echo e($errors->get('lokasi') ? 'is-invalid'  : ''); ?>"
                                name="lokasi" id="exampleFormControlTextarea1" rows="3"
                                required><?php echo e(old('lokasi')); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="ket" class="form-label">Keterangan</label>
                            <textarea class="form-control  
                                <?php echo e($errors->get('ket') ? 'is-invalid'  : ''); ?>" name="ket"
                                id="exampleFormControlTextarea1" rows="3"><?php echo e(old('ket')); ?> </textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a class='btn btn-warning ml-3' href='<?php echo e(url("barang/list")); ?>'>Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js')); ?>/main.js" ></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\invetory\resources\views/barang/input.blade.php ENDPATH**/ ?>