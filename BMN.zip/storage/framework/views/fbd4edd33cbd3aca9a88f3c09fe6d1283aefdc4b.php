

<?php $__env->startSection('main'); ?>
<div class="card container-fluid py-3 px-md-4">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <strong>Data Invetory</strong>
        </div>
        <div class="col-md-6 col-sm-12 px-3 text-end align-middle align-self-center hide-to-mobile">
            <span class="fst-italic fs-6">Dashboard > data
            </span>
        </div>
    </div>
</div>
<div class="pt-3">
    <div class="container-fluid">
        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card p-3">
                    <form action="/satuan/update/<?php echo e($satuan->id); ?>" method="post">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="nama_satuan" class="form-label">Edit Nama Satuan</label>
                            <input value="<?php echo e(old('nama_satuan',$satuan->nama_satuan)); ?>" type="text" class="form-control" id="exampleInputSatuan"
                                name="nama_satuan">
                            <div class="form-text">Silahkan Input Satuan</div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a class='btn btn-warning ml-3' href='<?php echo e(url("satuan/list")); ?>'>Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Yog\proj\inventaris\laravel\BMN\resources\views/satuan/edit.blade.php ENDPATH**/ ?>