<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ActionLogController extends Controller
{
    //
}
