<main >
    
    @yield('main')
</main>