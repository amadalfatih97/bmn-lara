<?php return array (
  'barang-live' => 'App\\Http\\Livewire\\BarangLive',
  'data-permintaan' => 'App\\Http\\Livewire\\DataPermintaan',
  'home-live' => 'App\\Http\\Livewire\\HomeLive',
  'pemeliharaan-live' => 'App\\Http\\Livewire\\PemeliharaanLive',
  'permintaan-live' => 'App\\Http\\Livewire\\PermintaanLive',
);